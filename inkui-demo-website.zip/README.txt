
InkUI Demo Website

Open index.html in your browser.
No build tools required.

Files:
- index.html  → Demo page
- inkui.css   → InkUI v1 demo styles
